
import java.util.Scanner;

/**
 * @author lujain Abdullah
 */
public class Application {

//*********************MAIN METHOD**************************

    /**
     *
     * @param args
     */
        public static void main(String[] args) {
        // scanner to read the input from the user 
        Scanner input = new Scanner(System.in);

        //counter of the running times 
        int running = 0;

        // loop to runn the algorithms ten times 
        while (running < 10) {
            // create a graph object 
            Graph g = null;
            //printing the choices for the user 
            System.out.println("");
            System.out.println("Algorithm Project Part 1 ");
            System.out.println("choose one of the following list to print the result for it:");
            System.out.println("n is the number of vertecies and m is the number of edges ");
            System.out.println("1- n=1000 , m=10000");
            System.out.println("2- n=1000 , m=15000");
            System.out.println("3- n=1000 , m=25000");
            System.out.println("4- n=5000 , m=15000");
            System.out.println("5- n=5000 , m=25000");
            System.out.println("6- n=10000 , m=15000");
            System.out.println("7- n=10000 , m=25000");
            System.out.println("8- n=20000 , m=200000");
            System.out.println("9- n=20000 , m=300000");
            System.out.println("10- n=50000 , m=1000000");
            System.out.println("");
            System.out.println("Enter Your Choice: ");

            // reading the choice from user 
            int choice = input.nextInt();

            // switch statement to initialize the graph based on the user choice 
            switch (choice) {
                case 1:
                    g = new Graph(1000, 10000, false);
                    break;
                case 2:
                    g = new Graph(1000, 15000, false);
                    break;
                case 3:
                    g = new Graph(1000, 25000, false);
                    break;
                case 4:
                    g = new Graph(5000, 15000, false);
                    break;
                case 5:
                    g = new Graph(5000, 25000, false);
                    break;
                case 6:
                    g = new Graph(10000, 15000, false);
                    break;
                case 7:
                    g = new Graph(10000, 25000, false);
                    break;
                case 8:
                    g = new Graph(20000, 200000, false);
                    break;
                case 9:
                    g = new Graph(20000, 300000, false);
                    break;
                case 10:
                    g = new Graph(50000, 1000000, false);
                    break;
                default:
                    System.out.println("you entered wrong choice try again ");

            }// end switch  

            // printing the algorithms to the user to choose one 
            System.out.println("1- Kruskal's Algorithm AND Prim's Algorithm based on Priority Queue");
            System.out.println("2- Prim's Algorithm based on Min Heap AND Prim's Algorithm based on Priority Queue");
            System.out.println("");
            System.out.println("Enter Your Choice: ");

            // reading the choice of the algorithm from user 
            int choiceAlgorithm = input.nextInt();

            // if the user choose the first choice  
            if (choiceAlgorithm == 1) {
                // create a min-heap prim object and calling the method 
                MHPrimAlg m = new MHPrimAlg(g);
                m.displayResultingMST(g);

                // create a Kruskal object and calling the method 
                KruskalAlg k = new KruskalAlg(g);
                k.displayResultingMST(g);

                // if the user choose the second choice 
            } else if (choiceAlgorithm == 2) {
                // create a min-heap prim object and calling the method 
                MHPrimAlg m = new MHPrimAlg(g);
                m.displayResultingMST(g);

                // create a priority queue prim object and calling the method 
                PQPrimAlg q = new PQPrimAlg(g);
                q.displayResultingMST(g);

                //else if the user enter wrong choice
            } else {
                System.out.println("you entered wrong choice try again ");
            }
            //increament the running counter
            running++;
        }
    }
    //----------------------END MAIN ---------------------------------------
}
