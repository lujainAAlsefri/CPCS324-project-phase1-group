
/**
 * @author lujain Abdullah
 */

//-----------------class Edge ---------------------------------
public class Edge {
     //-------------------variables----------------------

    /**
     *
     */
       private  int  weight;
 
    /**
     *
     */
    private   Vertex parent ; 
 
    /**
     *
     */
    private   Vertex Source; 

    /**
     *
     */
    private   Vertex Target;
  //-----------------------------------------------------
  
 // ---------------------constructers--------------------

    /**
     *
     * @param Source
     * @param Target
     * @param weight
     */
           public Edge(Vertex Source, Vertex Target , int weight) {
        this.weight = weight;
        this.Source = Source;
        this.Target = Target;
    }

    /**
     *
     * @param parent
     * @param weight
     */
    public Edge(Vertex parent,int weight) {
         this.weight = weight;
        this.parent = parent;
    }

    /**
     *
     * @param t
     */
    public Edge(Vertex t) {
        this.weight = 0;
        this.Source = t;
        this.Target = t;
        this.parent = t;
    }

    /**
     *
     */
    public Edge() {
    }
 //-----------------------------------------------------
    
//--------------------------- Method---------------------

    /**
     *
     * @return
     */
      public int getWeight() {
        return weight;
    }

    /**
     *
     * @param weight
     */
    public void setWeight(int weight) {
        this.weight = weight;
    }

    /**
     *
     * @return
     */
    public Vertex getParent() {
        return parent;
    }

    /**
     *
     * @param parent
     */
    public void setParent(Vertex parent) {
        this.parent = parent;
    }

    /**
     *
     * @return
     */
    public Vertex getSource() {
        return Source;
    }

    /**
     *
     * @param Source
     */
    public void setSource(Vertex Source) {
        this.Source = Source;
    }

    /**
     *
     * @return
     */
    public Vertex getTarget() {
        return Target;
    }

    /**
     *
     * @param Target
     */
    public void setTarget(Vertex Target) {
        this.Target = Target;
    }
 //-----------------------------------------------------
}
 //---------------------END Class--------------------------------
