
/**
 * @author lujain Abdullah
 */
// importing packeges
import java.util.LinkedList;
//---------------MHPrimAlg Class----------------------------------------

/**
 *
 * @author lujain Abdullah
 */
public class MHPrimAlg extends MSTAlgorithm {

//-------------------------------constructers------------------------------

    /**
     *
     * @param graph
     */
        public MHPrimAlg(Graph graph) {
        super(graph);
    }

    // ----------------------------methods----------------------------------
    // polymorphic method 

    /**
     *
     * @param graph
     */
        public void displayResultingMST(Graph graph) {
        //variable to save the starting time 
        Long Start = System.nanoTime();

        //variable to Cost the cost 
        int Cost = 0;

        //variable for the number of verteces 
        int v = graph.getVerticesNo();
        //array to save the verteces 
        Vertex V[] = graph.getVertices();
        //  1) Create a set mstSet that keeps track of vertices already included in MST.
        MSTresultList = new LinkedList<>();
        // array to check the tree for cycle 
        boolean[] inHeap = new boolean[v];

//2) Assign a key value to all vertices in the input graph. Initialize all key values as INFINITE. Assign key value as 0 for the first vertexLabel so that it is picked first. 
        //keys[] used to store the key to know whether min heap update is required
        int[] key = new int[v];
        //create heapNode for all the vertices
        HeapNode[] resultSet = new HeapNode[v];
        HeapNode[] heapNodes = new HeapNode[v];
        //loop to go over all verteces
        for (int i = 0; i < v; i++) {
            heapNodes[i] = new HeapNode();
            heapNodes[i].vertexLabel = i;
            heapNodes[i].wieght = Integer.MAX_VALUE;
            resultSet[i] = new HeapNode();
            resultSet[i].vertexLabel = -1;
            inHeap[i] = true;
            key[i] = Integer.MAX_VALUE;
        }//end for 
        //decrease the key for the first index
        heapNodes[0].wieght = 0;

        MinHeap minHeap = new MinHeap(v);
        //loop to add all the vertices to priority queue
        for (int i = 0; i < v; i++) {
            minHeap.insert(heapNodes[i]);
        }//end for 

        //linked list to save the edges of the tree
        LinkedList<Edge> adjList = null;

//3) While mstSet doesn’t include all vertices
        while (!minHeap.isEmpty()) {

            HeapNode extractedNode = minHeap.extractMin();
            //extracted vertexLabel
            int extractedVertex = extractedNode.vertexLabel;
            inHeap[extractedVertex] = false;
            //iterate through all the adjacent vertices
            adjList = graph.getVertices()[extractedVertex].getAdjList();
            for (int i = 0; i < adjList.size(); i++) {
                Edge e = adjList.get(i);
                //only if edge Target is present in heap  
                if (inHeap[e.getTarget().getLabel()]) {
                    int Target = e.getTarget().getLabel();
                    int newKey = e.getWeight();
                    //check if updated key < existing key, if yes, update if
                    if (key[Target] > newKey) {
                        this.decreaseKey(minHeap, newKey, Target);
                        //update the parent HeapNode for Target
                        resultSet[Target].vertexLabel = extractedVertex;
                        resultSet[Target].wieght = newKey;
                        key[Target] = newKey;
                    }//end if 
                }//end if 
            }//end for 
        }//end loop

// loop to add all edges that are making MST
        for (int i = 0; i < resultSet.length; i++) {
            Edge e = graph.getEdge(i, resultSet[i].vertexLabel);
            MSTresultList.add(e);
            if (e != null) {
                Cost = e.getWeight() + Cost;
            }
        }//end for 

        //variable to save the end time 
        Long End = System.nanoTime();
        //printing the cost 
        System.out.println("The Cost Of Minimum Spanning Tree is: " + Cost);
        //printing the running time 
        System.out.println("The Time For Executing Prim based on min heap Algorithm is: " + (End - Start));
    }//end method 
//----------------------------------------------------------------------------------------------------------------------------

//method to update the key of spesific vertexLabel 

    /**
     *
     * @param minHeap
     * @param newKey
     * @param vertex
     */
        void decreaseKey(MinHeap minHeap, int newKey, int vertex) {
        //get the index which key's needs a decrease;
        int index = minHeap.indexes[vertex];

        //get the node and update its value
        HeapNode node = minHeap.MinHeap[index];
        node.wieght = newKey;
        minHeap.bubbleUp(index);
    }
//----------------------------------------------------------------------------------------------------------

    //method to print the edges of the minimum spanning tree 

    /**
     *
     * @param e
     */
        public void print(LinkedList<Edge> e) {
        for (int i = 1; i < e.size(); i++) {
            Edge edge = e.get(i);
            if (edge == null) {
                continue;
            }
            System.out.print("[" + edge.getSource().getLabel() + "]-- ]  " + edge.getWeight() + "  Tar" + edge.getTarget().getLabel());
            System.out.println("");
        }
    }
//----------------------------Heap Node Class-----------------------------------

    /**
     *
     */
    class HeapNode {

        //-------------variables------------------

        /**
         *
         */
        
        int vertexLabel;

        /**
         *
         */
        int wieght;
//-------------------constructors------------------------

        /**
         *
         * @param vertex
         * @param wieght
         */
        public HeapNode(int vertex, int wieght) {
            this.vertexLabel = vertex;
            this.wieght = wieght;
        }

        /**
         *
         */
        public HeapNode() {
        }
        //-----------------------------------------------------
    }//End class
//-------------------------------------------------------------------------------------------------------
//----------------------------Min Heap Class-----------------------------------

    /**
     *
     */
    class MinHeap {

        //-------------variables------------------

        /**
         *
         */
        
        int capacity;

        /**
         *
         */
        int Size;

        /**
         *
         */
        HeapNode[] MinHeap;

        /**
         *
         */
        int[] indexes; //will be used to decrease the key
//-------------------constructors------------------------

        /**
         *
         * @param capacity
         */
        public MinHeap(int capacity) {
            this.capacity = capacity;
            MinHeap = new HeapNode[capacity + 1];
            indexes = new int[capacity];
            MinHeap[0] = new HeapNode();
            MinHeap[0].wieght = Integer.MIN_VALUE;
            MinHeap[0].vertexLabel = -1;
            Size = 0;
        }
//------------------------------------------------------------
//----------methods --------------------------------------

        /**
         *
         * @param x
         */
        public void insert(HeapNode x) {
            Size++;
            int idx = Size;
            MinHeap[idx] = x;
            indexes[x.vertexLabel] = idx;
            bubbleUp(idx);
        }
//-----------------------------------------------------------

        /**
         *
         * @param pos
         */
        public void bubbleUp(int pos) {
            int parentIdx = pos / 2;
            int currentIdx = pos;
            while (currentIdx > 0 && MinHeap[parentIdx].wieght > MinHeap[currentIdx].wieght) {
                HeapNode currentNode = MinHeap[currentIdx];
                HeapNode parentNode = MinHeap[parentIdx];

                //swap the positions
                indexes[currentNode.vertexLabel] = parentIdx;
                indexes[parentNode.vertexLabel] = currentIdx;
                swap(currentIdx, parentIdx);
                currentIdx = parentIdx;
                parentIdx = parentIdx / 2;
            }
        }
//-------------------------------------------------------

        /**
         *
         * @return
         */
        public HeapNode extractMin() {
            HeapNode min = MinHeap[1];
            HeapNode lastNode = MinHeap[Size];
// update the indexes[] and move the last node to the top
            indexes[lastNode.vertexLabel] = 1;
            MinHeap[1] = lastNode;
            MinHeap[Size] = null;
            sinkDown(1);
            Size--;
            return min;
        }
//------------------------------------------------------------

        /**
         *
         * @param k
         */
        public void sinkDown(int k) {
            int smallest = k;
            int leftChildIdx = 2 * k;
            int rightChildIdx = 2 * k + 1;
            if (leftChildIdx < heapSize() && MinHeap[smallest].wieght > MinHeap[leftChildIdx].wieght) {
                smallest = leftChildIdx;
            }
            if (rightChildIdx < heapSize() && MinHeap[smallest].wieght > MinHeap[rightChildIdx].wieght) {
                smallest = rightChildIdx;
            }
            if (smallest != k) {

                HeapNode smallestNode = MinHeap[smallest];
                HeapNode kNode = MinHeap[k];

                //swap the positions
                indexes[smallestNode.vertexLabel] = k;
                indexes[kNode.vertexLabel] = smallest;
                swap(k, smallest);
                sinkDown(smallest);
            }
        }
//----------------------------------------------------------------------------

            /**
             *
             * @param a
             * @param b
             */
            public void swap(int a, int b) {
            HeapNode temp = MinHeap[a];
            MinHeap[a] = MinHeap[b];
            MinHeap[b] = temp;
        }
//-------------------------------------------------------------------------------

        /**
         *
         * @return
         */
        public boolean isEmpty() {
            return Size == 0;
        }
//-----------------------------------------------------------------------------------

        /**
         *
         * @return
         */
        public int heapSize() {
            return Size;
        }
    }
    //---------------------------------------------------------------------------------
}//end class
//--------------------------------------------------------------------------------------
