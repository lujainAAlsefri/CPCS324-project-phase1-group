
/**
 * @author lujain Abdullah
 */
// importing packeges
import java.util.LinkedList;

//---------------Vertex Class----------------------------------------

/**
 *
 * @author lujain Abdullah
 */
public class Vertex {

    //----------------------variables---------------------------------

    /**
     *
     */
        private int label;

    /**
     *
     */
    private boolean isVisited;

    /**
     *
     */
    private LinkedList<Edge> adjList;

    /**
     *
     */
    private int Key;

    //-----------------------------------------------------------------
    //------------------------constructers-------------------------------- 

    /**
     *
     */
        public Vertex() {
    }

    /**
     *
     * @param label
     * @param isVisited
     */
    public Vertex(int label, boolean isVisited) {
        this.label = label;
        this.isVisited = isVisited;
        adjList = new LinkedList<>();

    }

    //-----------------------------------------------------------------------
    //setter and getter  methods 

    /**
     *
     * @param Key
     */
        public void setKey(int Key) {
        this.Key = Key;
    }

    /**
     *
     * @return
     */
    public int getKey() {
        return Key;
    }

    /**
     *
     * @return
     */
    public int getLabel() {
        return label;
    }

    /**
     *
     * @param label
     */
    public void setLabel(int label) {
        this.label = label;
    }

    /**
     *
     * @return
     */
    public boolean isIsVisited() {
        return isVisited;
    }

    /**
     *
     * @param isVisited
     */
    public void setIsVisited(boolean isVisited) {
        this.isVisited = isVisited;
    }

    /**
     *
     * @return
     */
    public LinkedList<Edge> getAdjList() {
        return adjList;
    }

    /**
     *
     * @param adjList
     */
    public void setAdjList(LinkedList<Edge> adjList) {
        this.adjList = adjList;
    }
}//End class
//-------------------------------------------------------------------------------
