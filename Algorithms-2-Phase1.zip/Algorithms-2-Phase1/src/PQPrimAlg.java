
/**
 * @author lujain Abdullah
 */
// importing packeges
import java.util.*;
//---------------PQPrimAlg Class----------------------------------------

/**
 *
 * @author lujain Abdullah
 */
public class PQPrimAlg extends MSTAlgorithm {

    // ---------------------------constructer-----------------------------------

    /**
     *
     * @param graph
     */
        public PQPrimAlg(Graph graph) {
        super(graph);
    }

    //-------------------------------------------------------------------------------
    //-----------------------------methods---------------------------------------
    // polymorphic method 

    /**
     *
     * @param g
     * @return
     */
        public String displayResultingMST(Graph g) {
        //variable to save the starting time 
        Long Start = System.nanoTime();

        //variable to Cost the cost 
        int Cost = 0;

        // array to check Whether a vertex is in PriorityQueue or not
        Boolean[] MST = new Boolean[g.getVerticesNo()];
        HeapNode[] VertecesList = new HeapNode[g.getVerticesNo()];

        // Stores the parents of a vertex and there weight
        int parent[] = new int[g.getVerticesNo()];

        //loop to initialize the list array 
        for (int i = 0; i < g.getVerticesNo(); i++) {
            VertecesList[i] = new HeapNode();
        }//end for 

        //loop to traverse all verteces 
        for (int i = 0; i < g.getVerticesNo(); i++) {
            MST[i] = false;
            VertecesList[i].key = Integer.MAX_VALUE;// Initialize key values to infinity
            VertecesList[i].vertex = i;
            parent[i] = -1; // -1 is NIL
        }//endfor 

        // Include the source vertex in MST set
        MST[0] = true;

        // Set key of the first element in the queue as 0 
        VertecesList[0].key = 0;

        //create the queue object 
        PriorityQueue<HeapNode> queue = new PriorityQueue<>(Comparator.comparingInt(o -> o.key));

        //loop to add all verteces to the queue 
        for (int i = 0; i < g.getVerticesNo(); i++) {
            queue.add(VertecesList[i]);
        }//end for 

        // Loops until the queue is not empty
        while (!queue.isEmpty()) {

            // Extracts a node with min key value
            HeapNode FirstNode = queue.poll();

            // Include that node into mstset
            MST[FirstNode.vertex] = true;

            // For all adjacent vertex of the extracted vertex V
            for (Edge iterator : g.getAdjacencylist(FirstNode.vertex)) {

                // If V is in queue
                if (MST[iterator.getTarget().getLabel()] == false) {

                    // If the key value of the adjacent vertex is more than the extracted key update the key value of adjacent vertex
                    // to update first remove and add the updated vertex
                    if (VertecesList[iterator.getTarget().getLabel()].key > iterator.getWeight()) {
                        // remove parent from queue
                        queue.remove(VertecesList[iterator.getTarget().getLabel()]);
                        // change its key with its weight (because its weight is smaller)
                        VertecesList[iterator.getTarget().getLabel()].key = iterator.getWeight();
                        //add the parent again in the queue
                        queue.add(VertecesList[iterator.getTarget().getLabel()]);
                        // update the value of parent
                        parent[iterator.getTarget().getLabel()] = FirstNode.vertex;
                    }//end if 
                }//end if 
            }//end for 
        }//end while 

        // loop to add all edges that are making MST
        for (int i = 0; i < g.getVerticesNo(); i++) {
            LinkedList<Edge> edge = g.getAdjacencylist(i);
            for (int j = 0; j < edge.size(); j++) {
                if (edge.get(j).getSource().getLabel() == i && edge.get(j).getTarget().getLabel() == parent[i]) {
                    super.getMSTresultList().add(edge.get(j));
                }//end if 
            }//end 
        }//end for 

        //loop to sum the cost of the tree
        for (int i = 0; i < super.getMSTresultList().size(); i++) {
            Cost += super.MSTresultList.get(i).getWeight();
        }//end for 

        //variable to save the end time 
        Long End = System.nanoTime();

        //printing the cost 
        System.out.println("The Cost Of Minimum Spanning Tree is:" + Cost);
        //printing the running time 
        System.out.println("The Time For Executing Prim based on Priority queue Algorithm is " + (End - Start));

        return "";
    }//end method 
    //------------------------------------------------------------------------------------------------------
}//end class
//--------------------------------------------------------------------------------------------------------------------
